package cs203.project07;

import cs203.battlearena.objectmon.*;
import cs203.project06.JsonObjectdex;
import cs203.battlearena.ObjectmonNameGenerator;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.io.IOException;
import java.io.File;
import java.io.FilenameFilter;

import java.util.*;


public class App {

    private JFrame frame;
    private Objectdex objectdex;
    private ObjectdexView objectdexView;
    private JMenuBar menuBar;

    public App() {
        this.objectdex = new JsonObjectdex();
        frame = new JFrame("ObjectDex Browser");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void loadObjectdex(String objectdexPath) throws Exception {
        objectdex.load(objectdexPath);
        setObjectdex(objectdex);
    }

    public void createAndAddOpenObjectdexMenuItem (JMenu menu) { 
        JMenuItem openMenuItem = new JMenuItem("Open Objectdex");
        openMenuItem . addActionListener (new ActionListener () {
            public void actionPerformed ( ActionEvent e ) {
                String cwd = System.getProperty("usr.dir");
                JFileChooser fc = new JFileChooser(cwd);
                FileNameExtensionFilter extFilter = new FileNameExtensionFilter("OBJECTDEX FILES", "objectdex", "objectdex");
                fc.setFileFilter(extFilter);
                int retVal = fc.showOpenDialog(frame);
                if (retVal == JFileChooser.APPROVE_OPTION) {
                    File file = fc . getSelectedFile();
                    String path = file.getPath();
                    try {
                        loadObjectdex(path);
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(frame, ex.toString());
                    }
                }
            }
        });
        menu.add(openMenuItem);
    }

    public void createAndAddSaveObjectdexMenuItem (JMenu menu) {
        JMenuItem saveMenuItem = new JMenuItem("Save Objectdex");
        saveMenuItem . addActionListener (new ActionListener () {
            public void actionPerformed (ActionEvent e) {
                String cwd = System.getProperty("usr.dir");
                JFileChooser fc = new JFileChooser(cwd);
                FileNameExtensionFilter extFilter = new FileNameExtensionFilter("OBJECTDEX FILES", "objectdex", "objectdex");
                fc.setFileFilter(extFilter);
                int retVal = fc.showOpenDialog(frame);
                if (retVal == JFileChooser.APPROVE_OPTION) {
                    File file = fc . getSelectedFile();
                    String path = file.getPath();
                    try {
                        objectdex.save(path);
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(frame, ex.toString());
                    } 
                }
            }
        });
        menu.add(saveMenuItem);
    }

    public void createAndShowGui() throws Exception {
        createAndAddMenuBar();
        objectdexView = createObjectdexView(createObjectdex (5));
        frame.getContentPane().add(objectdexView, BorderLayout.CENTER);
        frame.pack();
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public void setObjectdex (Objectdex objectdex) throws Exception {
        this.objectdex = objectdex;
        if (objectdexView != null) {
            frame.remove (objectdexView);
        }
        objectdexView = createObjectdexView(objectdex);
        frame.getContentPane().add(objectdexView, BorderLayout.CENTER);
        frame.pack();
        frame.validate();
        frame.repaint();
    }

    protected void createAndAddMenuBar() throws Exception {
        menuBar = new JMenuBar();
        createAndAddFileMenu();
        frame.setJMenuBar(menuBar);
    }

    protected void createAndAddFileMenu () {
        JMenu fileMenu = new JMenu("File");
        createAndAddNewObjectdexMenuItem(fileMenu);
        createAndAddOpenObjectdexMenuItem(fileMenu);
        createAndAddSaveObjectdexMenuItem(fileMenu);
        menuBar.add(fileMenu);
    }
    
    protected void createAndAddNewObjectdexMenuItem (JMenu menu) {
        JMenuItem newMenuItem = new JMenuItem("New Objectdex");
        newMenuItem.addActionListener(new ActionListener() {
            public void actionPerformed (ActionEvent e) {
                try {
                    String number = JOptionPane.showInputDialog (frame, "How many Objectmon to generate?", 5);
                    int numToGen = Integer.parseInt(number);
                    objectdex = createObjectdex(numToGen);
                }
                catch(NumberFormatException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, ex.toString());
                    return;
                }
                catch(Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, ex.toString());
                    return;
                }
                try {
                    setObjectdex(objectdex);
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, ex.toString());
                    return;
                }
            }
        });
        menu.add(newMenuItem);
    }

    public ObjectdexView createObjectdexView (Objectdex objectdex) throws Exception {
        return new ObjectdexView(objectdex ); 
    }

    public Objectdex createObjectdex (int numEntries) throws Exception {
        if (numEntries < 0) {
            throw new Exception("Can't create Objectdex with less than one entry.");
        }
        Objectdex od = new JsonObjectdex();
        for(int i = 0; i < numEntries; i++) {
            Objectmon omon = new Objectmon(ObjectmonNameGenerator.nextName());
            od.put(omon.getName(), new ObjectdexEntry(omon.getName(), omon.getHp(), omon.getStamina(), omon.getWeight()));
        }
        return od;
    }

    public static void main(String[] args) {
        App app = new App();
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    app.createAndShowGui();
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                    System.exit(1);
                }
            }
        });
    }
}
