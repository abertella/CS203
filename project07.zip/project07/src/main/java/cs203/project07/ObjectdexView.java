package cs203.project07;

import cs203.battlearena.objectmon.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ObjectdexView extends JPanel {
    private Objectdex objectdex;
    private JPanel cards;

    public ObjectdexView(Objectdex objectdex) throws Exception {
        super(new BorderLayout());
        this.objectdex = objectdex;
        cards = new JPanel(new CardLayout());
        for(ObjectdexEntry ode : objectdex.values()) {
            ObjectdexEntryView odev = createObjectdexEntryView (ode);
            cards.add(odev, ode.getName());
        }
        add(cards, BorderLayout.CENTER);
        createAndAddNavigateButtons();
    }
    public ObjectdexEntryView createObjectdexEntryView (ObjectdexEntry entry) throws Exception {
        return new ObjectdexEntryView(entry);
    }
    public void createAndAddNavigateButtons() throws Exception {
        java.net.URL imageURL;
        imageURL = getClass().getResource("left-arrow-small.png");
        if (imageURL != null) {
            ImageIcon imageIcon = new ImageIcon(imageURL, "previous");
            createAndAddPreviousButton(imageIcon);
        }
        else {
            throw new Exception("Objectdex left arrow image not found");
        }
        imageURL = getClass().getResource("right-arrow-small.png");
        if (imageURL != null) {
            ImageIcon imageIcon = new ImageIcon(imageURL, "next");
            createAndAddNextButton(imageIcon);
        }
        else {
            throw new Exception("Objectdex right arrow image not found");
        }
    }
    public void createAndAddPreviousButton(ImageIcon imageIcon) {
        JButton btnPrevious = new JButton(imageIcon);
        btnPrevious.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                CardLayout cdl = (CardLayout)(cards.getLayout());
                cdl.previous(cards);
            }
        });
        add(btnPrevious, BorderLayout.LINE_START);
    }
    public void createAndAddNextButton(ImageIcon imageIcon) {
        JButton btnNext = new JButton(imageIcon);
        btnNext.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                CardLayout cdl = (CardLayout)(cards.getLayout());
                cdl.next(cards);
            }
        });
        add(btnNext, BorderLayout.LINE_END);
    }
}