package cs203.project07;

import cs203.battlearena.objectmon.*;
import cs203.battlearena.gui.AbstractObjectmonView;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ObjectdexEntryView extends AbstractObjectmonView {
    private JLabel lblName;
    private JLabel lblHp;
    private JLabel lblStamina;
    private JLabel lblWeight;
    private JLabel lblImage;
    private ObjectdexEntry entry;

    public ObjectdexEntryView(ObjectdexEntry entry) throws Exception {
        super();
        this.entry = entry;
        JPanel statsPanel = new JPanel();
        BoxLayout statsLayout = new BoxLayout(statsPanel, BoxLayout.Y_AXIS);
        statsPanel.setLayout(statsLayout);
        lblName = new JLabel("Name: " + getName());
        statsPanel.add(lblName);
        lblHp = new JLabel("HP: " + getHp());
        statsPanel.add(lblHp);
        lblStamina = new JLabel("Stamina: " + getStamina());
        statsPanel.add(lblStamina);
        lblWeight = new JLabel("Weight: " + getWeight());
        statsPanel.add(lblWeight);
        add(statsPanel);
        lblImage = new JLabel(getImageIcon(), JLabel.CENTER);
        add(lblImage);
    }
    protected ObjectdexEntry getEntry() {
        return entry;
    }
    public String getName() {
        return entry.getName();
    }
    public int getHp() {
        return entry.getHp();
    }
    public int getStamina () {
        return entry.getStamina();
    }
    public int getWeight() {
        return entry.getWeight();
    }
    public ImageIcon getImageIcon() throws Exception {
        java.net.URL imageURL = getClass().getResource("no-image.png");
        if(imageURL != null) {
            ImageIcon imageIcon = new ImageIcon(imageURL, "default text");
            return imageIcon;
        }
        else {
            throw new Exception("ObjectdexEntryView image path not found (no-image.png)");
        }
    }
}