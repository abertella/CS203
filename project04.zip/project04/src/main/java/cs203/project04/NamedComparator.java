package cs203.project04;

import java.util.Comparator;
import cs203.battlearena.Named;

public class NamedComparator<T extends Named> implements Comparator<T>{

    public int compare(T o1, T o2) {
        String name1 = o1.getName();
        String name2 = o2.getName();
        return name1.compareTo(name2);
    }
}