package cs203.project04;

import java.lang.Integer;
import cs203.battlearena.objectmon.Objectmon;
import java.util.Comparator;

public class ObjectmonStaminaComparator<T extends Objectmon> implements Comparator<T>{

    public int compare(T o1, T o2) {
        Integer i1 = o1.getStamina();
        Integer i2 = o2.getStamina();
        return i1.compareTo(i2);
    }
}