package cs203.project04;

import java.lang.Integer;
import java.util.Comparator;

public class IntegerComparator<T extends Integer> implements Comparator<T>{
    
    public IntegerComparator(){}

    public int compare(T o1, T o2) {
        return o1.compareTo(o2);
    }
}