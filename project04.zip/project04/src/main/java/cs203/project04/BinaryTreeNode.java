package cs203.project04;

import cs203.battlearena.util.TreeNode;

public class BinaryTreeNode<T> implements TreeNode<T> {
    private T data;
    private TreeNode<T> rightNode;
    private TreeNode<T> leftNode;

    public BinaryTreeNode(T data) {
        this.data = data;
        this.rightNode = null;
        this.leftNode = null;
    }
    
    public void setRight(TreeNode<T> paramTreeNode) {
        this.rightNode = paramTreeNode;
    }
        
    public void setLeft(TreeNode<T> paramTreeNode) {
        this.leftNode = paramTreeNode;
    }
        
    public TreeNode<T> getRight() {
        return this.rightNode;
    }
        
    public TreeNode<T> getLeft() {
        return this.leftNode;
    }
        
    public T getData() {
        return this.data;
    }

    public String toString() {
        String dataString = this.data.toString();
        String rightChild = getRight().getData().toString();
        String leftChild = getLeft().getData().toString();
        String nodeString = String.format("Node: %s, Left Child: %s, Right Child: %s", dataString, leftChild, rightChild);
        return nodeString;
    }

} 