package cs203.project04;

import cs203.battlearena.util.Tree;
import java.util.Comparator;
import java.util.NoSuchElementException;
import cs203.battlearena.util.TreeNode;
import java.util.*;

public class BinaryTree<E> implements Tree<E> {
  
    private TreeNode<E> root;
    private int size;
    private Comparator<E> comparator;
    private List<E> list;

    public BinaryTree(Comparator<E> paramCompatator) {
      this.root = null;
      this.size = 0;
      this.comparator = paramCompatator;
      this.list = new ArrayList<E>();
    }

    public boolean insert(E e) {
      if (e == null) {
      return false;
    }
      else if (this.root == null && this.size == 0) {
        this.root = new BinaryTreeNode(e);
        this.size++;
        this.list.add(e);
        return true;
      }
      else {
        recursiveInsert(this.root, e);
        this.size++;
        this.list.add(e);
        return true;
      }
    }
    
    private void recursiveInsert(TreeNode<E> top, E insertValue) {
      if(compare(top.getData(), insertValue) <= 0){
        if(top.getRight() == null) {
          TreeNode<E> insertNode = new BinaryTreeNode(insertValue);
          top.setRight(insertNode);
        }
        else{
          recursiveInsert(top.getRight(), insertValue);
      }
    }
      else if(compare(top.getData(), insertValue) > 0){
        if(top.getLeft() == null) {
          TreeNode<E> insertNode = new BinaryTreeNode(insertValue);
          top.setLeft(insertNode);
        }
        else {
          recursiveInsert(top.getLeft(), insertValue);
        }
      }
    }
        
    public int size(){
      return this.size;
    }
        
    public boolean contains(E e) {
      if(this.root == null) {
        return false;
      }
      else {
        return recursiveContains(this.root, e);
      }
    }

    private boolean recursiveContains(TreeNode<E> top, E value) {
      if(compare(top.getData(), value) == 0) {
        return true;
      }
      else if(compare(top.getData(), value) < 0){
        if (top.getRight() == null) {
          return false;
        }
        else {
          return recursiveContains(top.getRight(), value);
        }
      }
      else if(compare(top.getData(), value) > 0) {
        if (top.getLeft() == null) {
          return false;
        }
        else {
          return recursiveContains(top.getLeft(), value);
        }
      }
      else {
        return false;
      }
    }
        
    public void clear() {
      this.root = null;
      this.size = 0;
      this.list.clear();
    }
        
    public E last() throws NoSuchElementException {
      if (this.root == null) {
        throw new NoSuchElementException();
      }
      else {
        return recursiveRight(this.root);
      }
    }

    private E recursiveRight(TreeNode<E> top) {
      if (top.getRight() == null) {
        return top.getData();
      }
      else {
        return recursiveRight(top.getRight());
      }
    }
        
    public E first() throws NoSuchElementException {
      if (this.root == null) {
        throw new NoSuchElementException();
      }
      else {
      return recursiveLeft(this.root);
      }
    }

    private E recursiveLeft(TreeNode<E> top){
      if (top.getLeft() == null) {
        return top.getData();
      }
      else {
        return recursiveLeft(top.getLeft());
      }
    }

    public E higher(E e) {
      if (this.root == null){
        return null;
      }
      else {
        return iterateHigher(e);
      }
    }

    private E iterateHigher(E e) {
      int i = 0;
      Collections.sort(list, comparator);
      Collections.reverse(list);
      if (compare(list.get(0), e) <= 0) {
        return null;
      }
      else {
        while(compare(list.get(i), e) > 0 && i+1 < list.size()) {
          if(compare(list.get(i+1), e) <= 0) {
            return list.get(i);
          }
        i++;
        }
      }
      return null;
    }

    public E lower(E e) {
      if (this.root == null){
        return null;
      }
      else {
        return iterateLower(e);
      }
    }

    private E iterateLower(E e) {
      int i = 0;
      Collections.sort(list, comparator);
      if (compare(list.get(0), e) >= 0) {
        return null;
      }
      else
        while(compare(list.get(i), e) < 0 && i+1 < list.size()) {
          if(compare(list.get(i+1), e) >= 0) {
            return list.get(i);
          }
        i++;
        }
      return null;
    }
    
    public boolean isEmpty() {
      return this.size == 0;
    }

    protected int compare(E o1, E o2) {
      return comparator.compare(o1, o2);
    }
}