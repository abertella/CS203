package cs203.project04;

import org.junit.Test;
import org.junit.Before;

import static org.junit.Assert.*;
import java.lang.Integer;
import java.util.Comparator;
import java.util.NoSuchElementException;

public class BinaryTreeTest {
    private BinaryTree<Integer> bTree;
    private Integer i0, i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11, i12;
    private Comparator<Integer> comp;

    @Before
    public void initEach() {
        i0 = 72; 
        i1 = 70; 
        i2 = 98; 
        i3 = 65; 
        i4 = 71; 
        i5 = 82;
        i6 = 101; 
        i7 = 50; 
        i8 = 68; 
        i9 = 79;
        i10 = 85;
        i11 = 0;
        i12 = 150;
        comp = new IntegerComparator();
        bTree = new BinaryTree(comp);
        bTree.insert(i0);
        bTree.insert(i1);
        bTree.insert(i2);
        bTree.insert(i3);
        bTree.insert(i4);
        bTree.insert(i5);
        bTree.insert(i6);
        bTree.insert(i7);
        bTree.insert(i8);
        bTree.insert(i9);
    }
    @Test
    public void testInsert() {
        assertTrue(bTree.insert(i10));
        assertTrue(bTree.contains(i10));
        assertFalse(bTree.insert(null)); 
    }
    @Test
    public void testSize() {
        assertEquals(bTree.size(), 10);
        bTree.insert(i10);
        assertEquals(bTree.size(), 11);
        bTree.clear();
        assertEquals(bTree.size(), 0);
    }
    @Test 
    public void testContains() {
        assertTrue(bTree.contains(i7));
        assertTrue(bTree.contains(i8));
        assertTrue(bTree.contains(i9));
        assertFalse(bTree.contains(i10));
        assertFalse(bTree.contains(i11));
    }
    @Test
    public void testClear() {
        bTree.clear();
        assertEquals(bTree.size(), 0);
        assertTrue(bTree.isEmpty());
    }
    @Test(expected = NoSuchElementException.class)
    public void testLast() {
        assertTrue(bTree.last().equals(i6));
        bTree.insert(i12);
        assertTrue(bTree.last().equals(i12));
        bTree.clear();
        bTree.last();
    }
    @Test(expected = NoSuchElementException.class)
    public void testFirst() {
        assertTrue(bTree.first().equals(i7));
        bTree.insert(i11);
        assertTrue(bTree.first().equals(i11));
        bTree.clear();
        bTree.first();
    }
    @Test
    public void testIsEmpty() {
        assertFalse(bTree.isEmpty());
        bTree.clear();
        assertTrue(bTree.isEmpty());
        bTree.insert(i4);
        assertFalse(bTree.isEmpty());
    }
    @Test
    public void testHigher() {
        assertTrue(bTree.higher(i8).equals(i1));
        assertEquals(bTree.higher(i6), null);
    }
    @Test
    public void testLower() {
        assertTrue(bTree.lower(i9).equals(i0));
        assertEquals(bTree.lower(i11), null);
    }
}