package cs203.project08;

import cs203.solutions.project07.ImageObjectdexEntryView;
import cs203.solutions.project07.ImageObjectdexEntry;

import cs203.battlearena.objectmon.*;
import cs203.battlearena.teams.Team;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.JLabel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.BorderLayout;

public class TeamBuilderEntryView extends ImageObjectdexEntryView {
    private Team team;
    private JPanel centerPanel;
    private TeamBuilderView parentView;

    public TeamBuilderEntryView(ImageObjectdexEntry entry, TeamBuilderView parentView) {
        super(entry);
        this.parentView = parentView;
    }

    public void createAndAddComponents() throws Exception {
        setLayout(new BorderLayout());
        centerPanel = new JPanel();
        add(centerPanel, BorderLayout.CENTER);
        super.createAndAddComponents();
        createAndAddAddToTeamButton(); 
    }

    public JButton createAndAddToTeamButton() {
        JButton btnAddToTeam = new JButton("Add to team");
        return btnAddToTeam;
    }

    public Team<Objectmon> getTeam() {
        return parentView . getTeam();
    }

    protected void addStatsPanel(JPanel statsPanel) {
        centerPanel.add(statsPanel);
    }

    protected void addImage(JLabel lblImage) {
        centerPanel.add(lblImage);
    }

    public Objectdex getObjectdex() {
        return parentView.getObjectdex();
    }

    protected void createAndAddAddToTeamButton () {
        JButton btnAddToTeam = createAndAddToTeamButton();
        addAddToTeamActionListener(btnAddToTeam);
        addAddToTeamButton (btnAddToTeam);
    }

    protected void addAddToTeamActionListener (JButton btnAddToTeam) {
        btnAddToTeam.addActionListener(new AddToTeamActionListener(this));
    }

    protected void addAddToTeamButton(JButton btnAddToTeam) {
        add(btnAddToTeam, BorderLayout.PAGE_END);
    }
}