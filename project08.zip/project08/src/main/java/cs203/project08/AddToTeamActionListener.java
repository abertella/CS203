package cs203.project08;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;

public class AddToTeamActionListener implements ActionListener {
    private TeamBuilderEntryView parentView;

    public AddToTeamActionListener (TeamBuilderEntryView parentView) {
        this.parentView = parentView;
    }

    public void actionPerformed (ActionEvent e) {
        
    }
}