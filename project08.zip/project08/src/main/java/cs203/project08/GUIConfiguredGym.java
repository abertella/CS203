package cs203.project08;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import cs203.project03.ListGym;
import cs203.project03.ListTeam;
import cs203.battlearena.teams.Team;
import cs203.battlearena.objectmon.Objectmon;

public class GUIConfiguredGym extends ListGym {
    public GUIConfiguredGym() {
        super();
    }

    protected int promptNumRounds() {
        String number = JOptionPane.showInputDialog(null, "How many rounds", 5);
        return Integer.parseInt(number);
    }

    protected int promptNumObjectmon(String team) {
        String number = JOptionPane.showInputDialog(null, "How many Objectmon on team " + team + "?");
        return Integer.parseInt(number);
    }

    protected String promptTeamName(String team) {
        return JOptionPane.showInputDialog(null, "What is team " + team + "'s name?");
    }

    public void configureFight() {
        try {
            setMaxRounds(promptNumRounds());
            int numOnTeamA = promptNumObjectmon("A");
            Team<Objectmon> newTeamA = new ListTeam<>();
            newTeamA.setMaxSize(numOnTeamA);
            newTeamA.setName(promptTeamName("A"));
            TeamBuilderDialog dlogA = new TeamBuilderDialog(newTeamA);
            Team<Objectmon> builtTeamA = dlogA.getBuiltTeam();
            if (builtTeamA == null || !(getTeamA().equals(builtTeamA))) {
                JOptionPane.showMessageDialog(null, "Team building failed. Hard exit.");
                System.exit(1);
            }
            int numOnTeamB = promptNumObjectmon("B");
            Team<Objectmon> newTeamB = new ListTeam<>();
            newTeamA.setMaxSize(numOnTeamB);
            newTeamA.setName(promptTeamName("B"));
            TeamBuilderDialog dlogB = new TeamBuilderDialog(newTeamB);
            Team<Objectmon> builtTeamB = dlogB.getBuiltTeam();
            if (builtTeamB == null || !(getTeamB().equals(builtTeamB))) {
                JOptionPane.showMessageDialog(null, "Team building failed. Hard exit.");
                System.exit(1);
            }
        }
        catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}