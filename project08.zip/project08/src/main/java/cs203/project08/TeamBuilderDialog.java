package cs203.project08;

import cs203.project03.ListTeam;

import cs203.solutions.project07.ImageApp;
import cs203.solutions.project07.ObjectdexView;
import cs203.solutions.project07.ImageObjectdexView;
import cs203.solutions.project07.ImageObjectdexEntry;
import cs203.solutions.project07.ImageJsonObjectdex;

import cs203.battlearena.ObjectmonNameGenerator;
import cs203.battlearena.objectmon.*;
import cs203.battlearena.teams.Team;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JDialog;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.BoxLayout;

import java.awt.Frame;
import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.GridLayout;

import java.io.IOException;
import java.io.File;
import java.io.FilenameFilter;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class TeamBuilderDialog extends JDialog {
    private Team team;
    private JPanel mainPanel;
    private Objectdex objectdex;
    private ObjectdexView objectdexView;
    private JMenuBar menuBar;

    public TeamBuilderDialog(Team team) throws Exception {
        this (null, team, new ImageJsonObjectdex()); 
    }

    public TeamBuilderDialog(Frame parent, Team team, ImageJsonObjectdex objectdex) throws Exception {
        super(parent, true);
        this.team = team;
        this.objectdex = objectdex;
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing (WindowEvent we) { 
                setVisible(false);
            }
        });
        createGUI();
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public ObjectdexView createObjectdexView(Objectdex objectdex) throws Exception { 
        return new TeamBuilderView (objectdex , this.team);
    }

    public void loadObjectdex (String objectdexPath) throws Exception {
        objectdex.load(objectdexPath);
        setObjectdex(objectdex);
    }

    public void setObjectdex (Objectdex objectdex) throws Exception {
        this.objectdex = objectdex;
        if (objectdexView != null) {
            mainPanel.remove(objectdexView);
        }
        objectdexView = createObjectdexView(objectdex);
        mainPanel.add(objectdexView);
        validate();
        pack();
        repaint();
        setLocationRelativeTo(null);
    }

    public Objectdex createObjectdex (int numEntries) throws Exception {
        if (numEntries < 1) {
            throw new Exception("Can't generate Objectdex with less than 1 entry");
        }
        Objectdex od = new ImageJsonObjectdex();
        File directory = new File("objectmon-icons-png");
        File[] objectmonIcons = directory.listFiles(new FilenameFilter() {
            public boolean accept(File directory , String fileName) {
                return fileName.endsWith(".png");
            }
        });
        List<File> iconFiles = Arrays.asList(objectmonIcons);
        for (int i = 0; i < numEntries; i++) {
            Objectmon omon = new Objectmon(ObjectmonNameGenerator.nextName());
            Collections.shuffle(iconFiles);
            String iconPath = iconFiles.get(0).getPath();
            od.put(omon.getName(), new ImageObjectdexEntry(omon.getName(), omon.getHp(), omon.getStamina(), omon.getWeight(), iconPath));
        }
        return od;
    }

    public void createGUI() throws Exception {
        setTitle("Pick your team members!");
        mainPanel = new JPanel();
        BoxLayout mainPanelLayout = new BoxLayout(mainPanel, BoxLayout.Y_AXIS);
        JPanel commandPanel = new JPanel(new GridLayout(0, 2));
        JButton btnNewObjectdex = new JButton("New Objectdex");
        //Add action listener
        commandPanel.add(btnNewObjectdex);
        JButton btnOpenObjectdex = new JButton("Open Objectdex");
        //Add action listener
        commandPanel.add(btnOpenObjectdex);
        mainPanel.add(commandPanel);
        add(mainPanel); 
    }

    public Team getBuiltTeam() {
        return this.team;
    }
}