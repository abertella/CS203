package cs203.project08;

import cs203.solutions.project07.ImageObjectdexView;
import cs203.solutions.project07.ImageObjectdexEntry;
import cs203.solutions.project07.ImageJsonObjectdex;
import cs203.solutions.project07.ObjectdexEntryView;

import cs203.battlearena.objectmon.*;
import cs203.battlearena.teams.Team;

public class TeamBuilderView extends ImageObjectdexView {
    private Team team;

    public TeamBuilderView(Team team) throws Exception {
        super(new ImageJsonObjectdex());
        this.team = team;
    }

    public TeamBuilderView(Objectdex objectdex, Team team) throws Exception {
        super(objectdex);
        this.team = team;
    }

    public Team getTeam() {
        return this.team;
    }

    public ObjectdexEntryView createObjectdexEntryView(ObjectdexEntryView entry) throws Exception {
        ImageObjectdexEntry iode = (ImageObjectdexEntry)entry;
        TeamBuilderEntryView tpev = new TeamBuilderEntryView(iode , this);
        return tpev;
    }
}