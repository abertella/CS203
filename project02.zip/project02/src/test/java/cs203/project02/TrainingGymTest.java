/*
 * Unit tests for the TrainingGym class.
 * 
 * @author Andrew Bertella
 */
package cs203.project02;

import org.junit.Test;
import static org.junit.Assert.*;

public class TrainingGymTest {
    TrainingGym TG = new TrainingGym();
    
    @Test public void testAddToTeamA() {
        TG.getTeamA().setMaxSize(2);
        Objectmon Test1 = new Objectmon("Itsy", 20, 20, 20);
        Objectmon Test2 = new Objectmon("Bitsy", 50, 50, 50);
        Objectmon Test3 = new Objectmon("Spider", 70, 70, 70);
        assertTrue(TG.addToTeamA(Test1));
        assertTrue(TG.addToTeamA(Test2));
        assertTrue(TG.getTeamA().contains(Test1));
        assertTrue(TG.getTeamA().contains(Test2));
        assertFalse(TG.addToTeamA(Test3));
    }
    @Test public void testAddToTeamB() {
        TG.getTeamB().setMaxSize(2);
        Objectmon Test1 = new Objectmon("Itsy", 20, 20, 20);
        Objectmon Test2 = new Objectmon("Bitsy", 50, 50, 50);
        Objectmon Test3 = new Objectmon("Spider", 70, 70, 70);
        assertTrue(TG.addToTeamB(Test1));
        assertTrue(TG.addToTeamB(Test2));
        assertTrue(TG.getTeamB().contains(Test1));
        assertTrue(TG.getTeamB().contains(Test2));
        assertFalse(TG.addToTeamB(Test3));
    }
    @Test public void testCanTeamAFight(){
        assertFalse(TG.canTeamAFight());
        TG.createRandomTeams(10);
        assertTrue(TG.canTeamAFight());
    }
    @Test public void testCanTeamBFight(){
        assertFalse(TG.canTeamAFight());
        TG.createRandomTeams(10);
        assertTrue(TG.canTeamAFight());
    }
    @Test public void testIsWinner() {
        TG.createRandomTeams(10);
        assertFalse(TG.isWinner());
        TG.getTeamA().clear();
        assertTrue(TG.isWinner());
    }
}