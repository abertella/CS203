
package cs203.project02;

import cs203.battlearena.AbstractGym;
import cs203.battlearena.ObjectmonNameGenerator;
import cs203.battlearena.objectmon.Objectmon;
import cs203.battlearena.teams.Team;
import cs203.battlearena.teams.BasicTeam;

import java.util.Scanner;
import java.util.StringJoiner;
/**
 * A TrainingGym class impliments the abstract methods in the AbstractGym class and some extras
 * 
 * @author Andrew Bertella
 */
public class TrainingGym extends AbstractGym {

    public TrainingGym() {
        super();
    }
    
    public boolean addToTeamA (Objectmon objectmon) {
        return super.getTeamA().add(objectmon);
    }
    
    public boolean addToTeamB (Objectmon objectmon) {
        return super.getTeamB().add(objectmon);
    }
    
    public boolean canTeamAFight() {
        return super.getTeamA().canFight();
    }
    
    public boolean canTeamBFight() {
        return super.getTeamB().canFight();
    }
    
    public void configureFight() {
        Scanner scan = new Scanner(System.in);
        int num_obj_team, num_rounds;
        String TeamA_name, TeamB_name;

        System.out.println("Enter number of Objectmon per team:");
        num_obj_team = scan.nextInt(); 
        System.out.println("Enter number of rounds:");
        num_rounds = scan.nextInt();
        System.out.println("Enter Team A name");
        TeamA_name = scan.next();
        System.out.println("Enter Team B name");
        TeamB_name = scan.next();
        System.out.println();
        this.createRandomTeams(num_obj_team);
        super.getTeamA().setName(TeamA_name);
        super.getTeamB().setName(TeamB_name);
    }

    public boolean isWinner() {
        return !(getTeamA().canFight() && getTeamB().canFight());
    }

    protected String toStringTeam (Team team_var) {
        if (team_var.isEmpty()) {
            return String.format("%s is empty", team_var.getName());
        }
        else {
            StringJoiner sj = new StringJoiner(", ", "[", "]");
            int num_obj = team_var.size();
            for (int i = 0; i < num_obj; i++) {
                sj.add(team_var.get(i).toString());
            }
            String team_string = String.format("%s contains %s", team_var.getName(), sj.toString());
            return team_string;
        }
    }

    public String toString() {
        String teamA_string = this.toStringTeam(getTeamA());
        String teamB_string = this.toStringTeam(getTeamB());
        return String.format("%s\n\n%s", teamA_string, teamB_string);
    }
    
    public void createRandomTeams(int num_obj_team) {
        super.getTeamA().setMaxSize(num_obj_team);
        for (int i = 0; i < num_obj_team; i++) {
          this.addToTeamA(new Objectmon(ObjectmonNameGenerator.nextName()));
        }
      
        super.getTeamB().setMaxSize(num_obj_team);
        for (int i = 0; i < num_obj_team; i++) {
          this.addToTeamB(new Objectmon(ObjectmonNameGenerator.nextName()));
        }
      }
    /**Takes user input to configute objectmon based on user input
     * @param obj_num the objectmon (offset) in the team
     * @param scan the scanner used in the calling function
     * @return a new objectmon configured to the user input
     */
    private Objectmon configureObjectmon(int obj_num, Scanner scan) {
        String obj_name;
        int hp, stamina, weight;

        System.out.println(String.format("Enter Objectmon %d name:", obj_num));
        obj_name = scan.next();
        System.out.println("Enter hp on this Objectmon");
        hp = scan.nextInt();
        System.out.println("Enter stamina on this Objectmon");
        stamina = scan.nextInt();
        System.out.println("Enter weight on this Objectmon");
        weight = scan.nextInt();
        return new Objectmon(obj_name, hp, stamina, weight);
    }
    /**Returns a team of objectmon configured with user input
     * @param team_var A Team initalized to the required size.
     * @param scan The scanner used in the calling function
     * @return team_var The team populated with user configured objectmon
     */
    private Team configureTeam(Team team_var, Scanner scan) {
        if (team_var.isEmpty()) {
            return team_var;
        }
        else {
            System.out.println(String.format("Team %s", team_var.getName()));
            for (int i = 0; i < team_var.getMaxSize(); i++) {
                int num_obj = i + 1;
                team_var.add(configureObjectmon(num_obj, scan));
            }
        return team_var;
        }
    }
    /** Allows user to configure teams. Lets the user input team names and set the number of objecmon per team
     * @param none
     * @return none
     */
    public void configureTeams() {
        Scanner scan = new Scanner(System.in);
        String teamA_name, teamB_name;
        int num_obj_team;

            System.out.println("Enter number of Objectmons per team:");
            num_obj_team = scan.nextInt();
            System.out.println("Enter Team A name");
            teamA_name = scan.next();
            System.out.println("Enter Team B name");
            teamB_name = scan.next();
            super.setTeamA(configureTeam(new BasicTeam(teamA_name, num_obj_team), scan));
            super.setTeamB(configureTeam(new BasicTeam(teamB_name, num_obj_team), scan));
            scan.close();
    }
}