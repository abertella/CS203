/*
 * App.java creating an instance of TrainingGym and calling some if its methods
 * @author Andrew Bertella
 */
package cs203.project02;


public class App {
    public static void main(String[] args) {

        TrainingGym TG = new TrainingGym();
        TG.createRandomTeams(10);
        System.out.println(TG.toString());
        TG.configureTeams();
        System.out.println(TG.toString());
    }
}
