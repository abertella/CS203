/**Main App
 * @author Andrew Bertella
*/
package cs203.project09;

import javax.swing.*;

    public class App {
        public App() {}
        public static void main(String[] args) {
          AndrewGUIGym gym = new AndrewGUIGym();
          SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              try {
                gym.createAndShowGUI();
              } catch (Exception ex) {
                System.err.println(ex);
                System.exit(1);
              }
        }
    });
    }
}
