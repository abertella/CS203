package cs203.project09;

import cs203.battlearena.teams.Team;
import cs203.project09.AndrewGUIGym;
import cs203.project09.ImageIconObjectmonGenerator;
import cs203.battlearena.objectmon.Objectmon;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**A dialog box in which the fight will be executed
 * The Objectmon are displayed side by side
 * @author Andrew Bertella
 */

public class FightDialog extends JPanel implements ActionListener {
    
    private AndrewGUIGym gym;
    private JSplitPane splPane;
    private ObjectmonFightView omanFVA, omanFVB;
    private JFrame frame;
    private ImageIconObjectmonGenerator iconGen;

    public FightDialog(AndrewGUIGym gym) {
        super(new BorderLayout());
        this.gym = gym;
        iconGen = new ImageIconObjectmonGenerator();
        Objectmon omanA = gym.getTeamA().nextObjectmon();
        Objectmon omanB = gym.getTeamB().nextObjectmon();
        omanFVA = new ObjectmonFightView(omanA, iconGen.getImageIcon(omanA.getName()));
        omanFVB = new ObjectmonFightView(omanB, iconGen.getImageIcon(omanB.getName()));
        splPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, omanFVA, omanFVB);
        splPane.setContinuousLayout(true);
        this.add(splPane, BorderLayout.CENTER);
        this.add(createTopLabel(0), BorderLayout.PAGE_START);
        this.add(createNextButton(), BorderLayout.PAGE_END);
    }
    
    private JButton createNextButton() {
        JButton nextBttn = new JButton("Next Turn");
        nextBttn.addActionListener(this);
        return nextBttn;
    }
    
    private JLabel createTopLabel(int round) {
        JLabel topLabel = new JLabel("Round " + round + " of " + gym.getMaxRounds());
        return topLabel;
    }
    
    public void actionPerformed(ActionEvent e) {
        gym.executeTurn();
    }
    
    public void createAndShowGUI(){
        frame = new JFrame(gym.getTeamA().getName() + " fights " + gym.getTeamB().getName());
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setOpaque(true);
        frame.setContentPane(this);
        frame.pack();
        frame.setVisible(true);
    }
    
    //Updates all the panes (both fight views and the upper label)/

    public void updatePanes(Objectmon omanA, Objectmon omanB, int round) {
        omanFVA = new ObjectmonFightView(omanA, iconGen.getImageIcon(omanA.getName()));
        omanFVB = new ObjectmonFightView(omanB, iconGen.getImageIcon(omanB.getName()));
        frame.getContentPane().removeAll();
        splPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, omanFVA, omanFVB);
        this.add(splPane, BorderLayout.CENTER);
        this.add(createTopLabel(round), BorderLayout.PAGE_START);
        this.add(createNextButton(), BorderLayout.PAGE_END);
        this.revalidate();
        this.repaint();
    }
    
    //Closes the window

    public void close() {
        frame.dispose();
    }
}