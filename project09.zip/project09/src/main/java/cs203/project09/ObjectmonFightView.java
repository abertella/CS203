package cs203.project09;

import java.awt.*;
import javax.swing.*;
import cs203.battlearena.objectmon.Objectmon;;

public class ObjectmonFightView extends JPanel {
    
    private Objectmon oman;
    private JLabel lblName;
    private JLabel lblProtip;
    private JLabel lblHp;
    private JLabel lblStamina;
    private JLabel lblWeight;
    private JLabel lblImage;

    public ObjectmonFightView(Objectmon oman, ImageIcon imageIcon) {
        super();
        this.oman = oman;
        JPanel statsPanel = new JPanel();
        BoxLayout statsLayout = new BoxLayout(statsPanel, BoxLayout.Y_AXIS);
        statsPanel.setLayout(statsLayout);
        lblName = new JLabel("Name: " + getName());
        statsPanel.add(lblName);
        lblHp = new JLabel("HP: " + getHp());
        statsPanel.add(lblHp);
        lblStamina = new JLabel("Stamina: " + getStamina());
        statsPanel.add(lblStamina);
        lblWeight = new JLabel("Weight: " + getWeight());
        statsPanel.add(lblWeight);
        add(statsPanel);
        lblImage = new JLabel(imageIcon, JLabel.CENTER);
        add(lblImage);
        }
        
        protected Objectmon getObjectmon() {
            return oman;
        }
        
        public String getName() {
            return oman.getName();
        }
        
        public int getHp() {
            return oman.getHp();
        }
        
        public int getStamina () {
            return oman.getStamina();
        }
        
        public int getWeight() {
            return oman.getWeight();
        }
}