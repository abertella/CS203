package cs203.project09;

import java.awt.*;
import javax.swing.*;

import cs203.solutions.project08.GUIConfiguredGym;
import cs203.battlearena.objectmon.*;
import cs203.project09.FightDialog;

import java.awt.event.*;

/**The main class for my gym. It displays the main frame with buttons to configure teams and then 
 * executes the fight.
 * @author Andrew Bertella
 */

public class AndrewGUIGym extends GUIConfiguredGym implements ActionListener {
    private JFrame frame;
    private int currentRound;
    private FightDialog fDiag;

    public AndrewGUIGym() {
        frame = new JFrame ("AndrewGUIGym");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void createAndAddLabel() {
        try {
            JLabel centerLabel = new JLabel(getIcon("pokeball.png"), JLabel.CENTER);
            centerLabel.setOpaque(true);
            centerLabel.setPreferredSize(new Dimension(600,600));
            frame.getContentPane().add(centerLabel, BorderLayout.CENTER);
        }catch(Exception e){
            System.err.println(e.getMessage());
        }
    }

    private void createAndAddButtons(){
        JButton configTeamsBttn = new JButton("Configure Teams");
        configTeamsBttn.setActionCommand("configteam");
        configTeamsBttn.addActionListener(this);
        frame.getContentPane().add(configTeamsBttn, BorderLayout.NORTH);
        JButton fightBttn = new JButton("Fight");
        fightBttn.setActionCommand("fight");
        fightBttn.addActionListener(this);
        frame.getContentPane().add(fightBttn, BorderLayout.SOUTH);
    }

    public void actionPerformed(ActionEvent e) {
        if("configteam".equals(e.getActionCommand())) {
            super.configureFight();
        }
        if("fight".equals(e.getActionCommand())) {      //execute fight
            try {
                currentRound = 0;
                fDiag = new FightDialog(this);
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        fDiag.createAndShowGUI();
                    }
                });
            }catch(Exception ex){
                JOptionPane.showMessageDialog(frame, "You must configure your teams first!");
            }
        }
    }

    public void createAndShowGUI() {
        createAndAddLabel();
        createAndAddButtons();
        frame.pack();
        frame.setVisible(true);
    }

    //A GUI friendly executeTurn

    public void executeTurn() {
        if(currentRound == getMaxRounds() || isWinner()){
            pickWinner();
            return;
        }
        tick();
        currentRound++;
        Objectmon omanA = getTeamA().nextObjectmon();
        Objectmon omanB = getTeamB().nextObjectmon();
        if ((omanA == null) || (omanB == null)) {
            return;
        }
        fDiag.updatePanes(omanA, omanB, currentRound);
        int damageDone = executeAttack(omanA, omanB);
        JOptionPane.showMessageDialog(fDiag, omanA.getName() + " deals " + damageDone + " damage to " + omanB.getName());
        omanB.setHp(omanB.getHp() - damageDone);
        fDiag.updatePanes(omanA, omanB, currentRound);
        if (omanB.isFainted()) {
            JOptionPane.showMessageDialog(fDiag, omanB.getName() + " fainted! Moving to next turn!");
                if(!canTeamBFight()){
                    pickWinner();
                }
            return;
          }
        damageDone = executeAttack(omanB, omanA);
        JOptionPane.showMessageDialog(fDiag, omanB.getName() + " deals " + damageDone + " damage to " + omanA.getName());
        omanA.setHp(omanA.getHp() - damageDone);
        fDiag.updatePanes(omanA, omanB, currentRound); 
        if (omanA.isFainted()) {
            JOptionPane.showMessageDialog(fDiag, omanA.getName() + " fainted! Moving to next turn!");
                if(!canTeamAFight()){
                    pickWinner();
                }
            return;
        }
    }

    private ImageIcon getIcon(String path) throws Exception {
        java.net.URL imageURL = getClass().getResource(path);
        if(imageURL != null) {
            ImageIcon imageIcon = new ImageIcon(imageURL, "default text");
            return imageIcon;
            }
        else {
            throw new Exception("Icon image path not found");
            }
    }

    //Picks the winner at the end of a round and informs user

  protected void pickWinner() {
    if((canTeamAFight()) && (canTeamBFight())){
        JOptionPane.showMessageDialog(fDiag, "It was a draw!");
        }
    else if (canTeamAFight()) {
        JOptionPane.showMessageDialog(fDiag, getTeamA().getName() + " won!");
        }
    else if (canTeamBFight()) {
        JOptionPane.showMessageDialog(fDiag, getTeamB().getName() + " won!");
        }
    else {
        JOptionPane.showMessageDialog(fDiag, "It was a draw!");
        }
    fDiag.close();
    }
}