package cs203.project09;

import java.util.HashMap;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import java.io.File;
import java.io.FilenameFilter;

import javax.swing.*;

/**A class to store ImageIcons according to objectmon name so when the panes are refreshed the image doesn't change
 * @author Andrew Bertella
*/

public class ImageIconObjectmonGenerator extends HashMap<String, ImageIcon> {

    private List<File> icons;

    public ImageIconObjectmonGenerator() {
        super();
        File directory = new File("objectmon-icons-png");
        File[] iconsFiles = directory.listFiles(new FilenameFilter(){
            public boolean accept(File dir, String name) {
                return name.endsWith(".png");
            }
        });
        icons = Arrays.asList(iconsFiles);
    }

    public ImageIcon getImageIcon(String name) {
        if (this.containsKey(name)) {
            return this.get(name);
        }
        Collections.shuffle(icons);
        ImageIcon newIcon = new ImageIcon(icons.get(0).getPath());
        this.put(name, newIcon);
        return newIcon;
    }
}