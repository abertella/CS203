I Andrew Bertella completed this project on my own, with no external help or information except the official Javadocs, official class textbook, class lectures or TAs.
I understand that any use of non-sanctioned materials (e.g., stack overflow, etc.) is considered cheating and will result in a zero for this project, as well as reporting to the department, college, and university for further actions.

I didn't implement anything cool, but I did this project alone.