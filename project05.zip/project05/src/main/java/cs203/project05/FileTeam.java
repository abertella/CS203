package cs203.project05;

import java.io.*;
import java.lang.Integer;
import java.util.StringJoiner;

import cs203.battlearena.io.Saveable;
import cs203.battlearena.objectmon.Objectmon;
import cs203.battlearena.teams.Team;
import cs203.battlearena.io.Loadable;
import cs203.project03.ListTeam;


public class FileTeam extends ListTeam implements Saveable, Loadable {
    
    public FileTeam() {
        super();
    }
    
    public void load(String inPath) throws IOException {
        BufferedReader in = null;
        try {
            in = new BufferedReader(new FileReader(inPath));
            String teamName, objectmon, objectmonName;
            String[] splitObjectmon;
            int maxSize, weight, stamina, hp;
    
            teamName = in.readLine();
            this.setName(teamName);
            maxSize = Integer.parseInt(in.readLine());
            this.setMaxSize(maxSize);
            while ((objectmon = in.readLine()) != null) {
                splitObjectmon = objectmon.split(",");
                objectmonName = splitObjectmon[0];
                hp = Integer.parseInt(splitObjectmon[1]);
                stamina = Integer.parseInt(splitObjectmon[2]);
                weight = Integer.parseInt(splitObjectmon[3]);
                if(this.add(new Objectmon(objectmonName, hp, stamina, weight))==false) {
                    throw new IOException("This team is invalid");
                    break;
                }
            }
        }
        finally {
            if (in != null) {
                in.close();
            }
        }
    }

    public void save(String outPath) throws IOException {
        BufferedWriter out = null;
        StringJoiner sj;
        try {
            out = new BufferedWriter(new FileWriter(outPath));
            String teamName, objectmonName, weight, stamina, hp;
            String teamString;
            teamName = this.getName() + "\n";
            teamString = teamName + this.getMaxSize() + "\n";
            out.write(teamString);
            
            int i = 0;
            while (this.get(i) != null) {
                sj = new StringJoiner(", ");
                sj.add(this.get(i).getName());
                sj.add(Integer.toString(this.get(i).getHP()));
                sj.add(Integer.toString(this.get(i).getStamina()));
                sj.add(Integer.toString(this.get(i).getWeight()));
                out.write(sj.toString());
                out.newLine();
                i++;
            }
        }
        finally {
            if (out != null) {
                out.close();
            }
        }
    }
}