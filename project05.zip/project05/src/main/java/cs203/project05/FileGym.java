package cs203.project05;

import cs203.project03.ListGym;
import cs203.project05.FileTeam;
import java.io.*;
import java.util.Scanner;

public class FileGym extends ListGym {
    public FileGym() {
        super(new FileTeam(), new FileTeam());
    }
    public FileGym(FileTeam TeamA, FileTeam TeamB) {
        super(TeamA, TeamB);
    }
    
    public void configureFight() {
        Scanner scan = new Scanner(System.in);
        int maxRounds;

        System.out.println("Enter TeamA file:");
        super.getTeamA().load(scan.next());
        System.out.println("Enter TeamB file:");
        super.getTeamB().load(scan.next());
        System.out.println("Enter number of rounds:");
        maxRounds = scan.nextInt();
        this.setMaxRounds(maxRounds);
    }
}