package cs203.project05;

import cs203.project05.FileGym;
import java.io.PrintStream;

public class App {

    public static void main(String[] args) {
        FileGym FG = new FileGym();
        FG.configureFight();
    }
}
