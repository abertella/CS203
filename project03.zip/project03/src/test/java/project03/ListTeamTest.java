package cs203.project03;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;

import cs203.battlearena.objectmon.Objectmon;

public class ListTeamTest {
    @Test public void testListTeam() {
        ListTeam listTeam1 = new ListTeam("Melissa", 50);
        ListTeam listTeam2 = new ListTeam();
        ListTeam listTeam3 = new ListTeam("Lilly");
        assertEquals("Melissa", listTeam1.getName());
        assertEquals(50, listTeam1.getMaxSize());
        assertEquals("ListTeam", listTeam2.getName());
        assertEquals(0, listTeam2.getMaxSize());
        assertEquals("Lilly", listTeam3.getName());
        assertEquals(0, listTeam2.getMaxSize());
    }
    @Test public void testAdd() {
        ListTeam listTeam1 = new ListTeam("Melissa", 2);
        ListTeam listTeam2 = new ListTeam();
        Objectmon testObjectmon1 = new Objectmon("Itsy", 40, 40, 40);
        assertTrue(listTeam1.add(testObjectmon1));
        assertTrue(listTeam1.contains(testObjectmon1));
        listTeam1.add(1, testObjectmon1);
        assertEquals(testObjectmon1, listTeam1.get(1));
    }
    @Test public void testAddAll() {
        ListTeam listTeam1 = new ListTeam("Melissa", 11);
        List testList1 = new ArrayList<Objectmon>(10);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 50, 50, 40);
        listTeam1.setAll(testObjectmon1);
        assertFalse(listTeam1.addAll(testList1));
    }
    @Test public void testClear() {
        ListTeam listTeam1 = new ListTeam("Melissa", 2);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40); 
        listTeam1.setAll(testObjectmon1);
        listTeam1.clear();
        assertTrue(listTeam1.isEmpty());
    }
    @Test public void testContains() {
        ListTeam listTeam1 = new ListTeam("Melissa", 2);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        listTeam1.add(testObjectmon1);
        assertTrue(listTeam1.contains(testObjectmon1));
        assertFalse(listTeam1.contains(testObjectmon2));
    }
    @Test public void testContainsAll() {
        ListTeam listTeam1 = new ListTeam("Melissa", 3);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        List testList1 = new ArrayList<Objectmon>(2);
        testList1.add(testObjectmon2);
        testList1.add(testObjectmon2);
        listTeam1.add(testObjectmon1);
        listTeam1.add(testObjectmon2);
        listTeam1.add(testObjectmon2);
        assertTrue(listTeam1.containsAll(testList1));
    }
    @Test public void testEquals() {
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        ListTeam listTeam1 = new ListTeam("Melissa", 3);
        ListTeam listTeam2 = new ListTeam("Melissa", 3);
        listTeam1.add(testObjectmon1);
        listTeam1.add(testObjectmon2);
        listTeam2.add(testObjectmon1);
        listTeam2.add(testObjectmon2);
        assertTrue(listTeam1.equals(listTeam2));
        listTeam1.add(testObjectmon2);
        assertFalse(listTeam1.equals(listTeam2));
    }
    @Test public void testGet() {
        ListTeam listTeam1 = new ListTeam("Melissa", 2);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        listTeam1.add(testObjectmon1);
        listTeam1.add(testObjectmon2);
        assertTrue(listTeam1.get(0).equals(testObjectmon1));
        assertTrue(listTeam1.get(1).equals(testObjectmon2));
    }
    @Test public void testSize() {
        ListTeam listTeam1 = new ListTeam("Melissa", 2);
        assertEquals(listTeam1.size(), 0);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        listTeam1.add(testObjectmon1);
        assertEquals(listTeam1.size(), 1);
        listTeam1.clear();
        assertEquals(listTeam1.size(), 0);
    }
    @Test public void testHashcode() {
        ArrayList testList1 = new ArrayList<Objectmon>(2);
        ListTeam listTeam1 = new ListTeam("Melissa", 2);
        assertEquals(listTeam1.hashCode(), testList1.hashCode());
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        listTeam1.add(testObjectmon1);
        testList1.add(testObjectmon1);
        assertEquals(listTeam1.hashCode(), testList1.hashCode());
    }
    @Test public void testIndexOf() {
        ListTeam listTeam1 = new ListTeam("Melissa", 2);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        listTeam1.add(testObjectmon1);
        listTeam1.add(testObjectmon2);
        assertEquals(listTeam1.indexOf(testObjectmon1), 0);
        assertEquals(listTeam1.indexOf(testObjectmon2), 1);
    }
    @Test public void testIsEmpty() {
        ListTeam listTeam1 = new ListTeam("Melissa", 2);
        assertTrue(listTeam1.isEmpty());
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        listTeam1.add(testObjectmon1);
        assertFalse(listTeam1.isEmpty());
    }
    @Test public void testIterator() {
        ListTeam listTeam1 = new ListTeam("Melissa", 2);
        List testList1 = new ArrayList<Objectmon>(2);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        listTeam1.add(testObjectmon1);
        listTeam1.add(testObjectmon2);
        testList1.add(testObjectmon1);
        testList1.add(testObjectmon2);
        assertTrue(listTeam1.iterator().next().equals(testList1.iterator().next()));
        assertTrue(listTeam1.iterator().next().equals(testList1.iterator().next()));
    }
    @Test public void testRemove() {
        ListTeam listTeam1 = new ListTeam("Melissa", 2);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        listTeam1.add(testObjectmon1);
        listTeam1.add(testObjectmon2);
        assertTrue(listTeam1.remove(0).equals(testObjectmon1));
        assertTrue(listTeam1.remove(testObjectmon2));
    }
    @Test public void testLastIndexOf() {
        ListTeam listTeam1 = new ListTeam("Melissa", 3);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        listTeam1.add(testObjectmon1);
        listTeam1.add(testObjectmon2);
        listTeam1.add(testObjectmon2);
        assertEquals(listTeam1.lastIndexOf(testObjectmon1), 0);
        assertEquals(listTeam1.lastIndexOf(testObjectmon2), 2);
    }
    @Test public void testRemoveAll() {
        ListTeam listTeam1 = new ListTeam("Melissa", 3);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        List testList1 = new ArrayList<Objectmon>(2);
        testList1.add(testObjectmon2);
        testList1.add(testObjectmon2);
        listTeam1.add(testObjectmon1);
        listTeam1.add(testObjectmon2);
        listTeam1.add(testObjectmon2);
        assertTrue(listTeam1.removeAll(testList1));
        assertEquals(listTeam1.size(), 1);        
    }
    @Test public void testRetainAll() {
        ListTeam listTeam1 = new ListTeam("Melissa", 3);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        List testList = new ArrayList<Objectmon>(2);
        testList.add(testObjectmon2);
        testList.add(testObjectmon2);
        listTeam1.add(testObjectmon1);
        listTeam1.add(testObjectmon2);
        listTeam1.add(testObjectmon2);
        assertTrue(listTeam1.retainAll(testList));
        assertEquals(listTeam1.size(), 2);
    }
    @Test public void testSet() {
        ListTeam listTeam1 = new ListTeam("Melissa", 3);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        listTeam1.add(testObjectmon1);
        listTeam1.add(testObjectmon2);
        listTeam1.add(testObjectmon2);
        assertTrue(listTeam1.set(2, testObjectmon1).equals(testObjectmon2));
    }
    @Test public void testSubList(){
        ListTeam listTeam1 = new ListTeam("Melissa", 3);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        List testList = new ArrayList<Objectmon>(2);
        testList.add(testObjectmon2);
        testList.add(testObjectmon2);
        listTeam1.add(testObjectmon1);
        listTeam1.add(testObjectmon2);
        listTeam1.add(testObjectmon2);
        assertTrue(listTeam1.subList(1,3).equals(testList));
    }
    @Test public void testToArray() {
        ListTeam listTeam1 = new ListTeam("Melissa", 2);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        List testList = new ArrayList<Objectmon>(2); 
        testList.add(testObjectmon2);
        testList.add(testObjectmon2);
        listTeam1.add(testObjectmon2);
        listTeam1.add(testObjectmon2);
        listTeam1.add(testObjectmon2);
        assertFalse(listTeam1.toArray().equals(testList.toArray()));
    }
    @Test public void testListIterator() {
        ListTeam listTeam1 = new ListTeam("Melissa", 3);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        List testList = new ArrayList<Objectmon>(2);
        testList.add(testObjectmon2);
        testList.add(testObjectmon2);
        testList.add(testObjectmon1);
        listTeam1.add(testObjectmon2);
        listTeam1.add(testObjectmon2);
        listTeam1.add(testObjectmon1);
        ListIterator testListIterator = testList.listIterator(1);
        ListIterator listTeam1Iterator = listTeam1.listIterator(1);
        assertTrue(listTeam1Iterator.next().equals(testListIterator.next()));
        assertTrue(listTeam1Iterator.next().equals(testListIterator.next()));
    }
    @Test public void testGetName() {
        ListTeam listTeam1 = new ListTeam("Melissa", 3);
        assertTrue(listTeam1.getName().equals("Melissa"));
        assertFalse(listTeam1.getName().equals("Evelyn"));
    }
    @Test public void testSetName() {
        ListTeam listTeam1 = new ListTeam();
        listTeam1.setName("Melissa");
        assertTrue(listTeam1.getName().equals("Melissa"));
        listTeam1.setName("Evelyn");
        assertTrue(listTeam1.getName().equals("Evelyn"));
    }
    @Test public void testGetMaxSixe() {
        ListTeam listTeam1 = new ListTeam("Melissa", 3);
        ListTeam listTeam2 = new ListTeam("Evelyn", 5);
        assertEquals(listTeam1.getMaxSize(), 3);
        assertEquals(listTeam2.getMaxSize(), 5);
    }
    @Test public void testSetMaxSixe() {
        ListTeam listTeam1 = new ListTeam();
        ListTeam listTeam2 = new ListTeam();
        listTeam1.setMaxSize(2);
        listTeam2.setMaxSize(5);
        assertEquals(listTeam1.getMaxSize(), 2);
        assertEquals(listTeam2.getMaxSize(), 5);
    }
    @Test public void testCanFight() {
        ListTeam listTeam1 = new ListTeam("Melissa", 3);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        listTeam1.add(testObjectmon1);
        listTeam1.add(testObjectmon2);
        assertTrue(listTeam1.canFight());
    }
    @Test public void testNextObjectmon() {
        ListTeam listTeam1 = new ListTeam("Melissa", 3);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        listTeam1.add(testObjectmon1);
        listTeam1.add(testObjectmon2);
        assertTrue(listTeam1.nextObjectmon().equals(testObjectmon1));
    }
    @Test public void testToString() {
        String teamEmpty = "Melissa is empty";
        String teamFull = "Melissa contains [{\"Itsy\",20,20,40,attacks:[{\"Basic Attack\"}],statusEffects:[]}]";
        ListTeam listTeam1 = new ListTeam("Melissa", 1);
        assertEquals(listTeam1.toString(), teamEmpty);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        listTeam1.add(testObjectmon1);
        assertEquals(listTeam1.toString(), teamFull);
    }
    @Test public void testTick() {
        ListTeam listTeam1 = new ListTeam("Melissa", 2);
        Objectmon testObjectmon1 = new Objectmon("Itsy", 20, 20, 40);
        Objectmon testObjectmon2 = new Objectmon("Bitsy", 23, 20, 40);
        listTeam1.add(testObjectmon1);
        listTeam1.add(testObjectmon2);
        listTeam1.tick();
        assertEquals(listTeam1.get(0).getStamina(), 21);
    }
}