package cs203.project03;

import org.junit.Test;
import static org.junit.Assert.*;

import cs203⁩.project02⁩.TrainingGym;
 
public class ListGymTest {
    @ Test public void testListGym() {
        ListGym testLG = new ListGym(); 
        assertTrue(testLG instanceof ListGym);
        assertTrue(testLG.getTeamA() instanceof ListTeam);
        assertTrue(testLG.getTeamB() instanceof ListTeam);
    }
}