package cs203.project03;

import cs203⁩.project02⁩.TrainingGym;
 /**
 * A ListGym class where TeamA ans TeamB are ListTeams
 * 
 * @author Andrew Bertella
 */
public class ListGym extends TrainingGym {

    public ListGym() {
        super(new ListTeam("TeamA"), new ListTeam("TeamB"));
    }
    public ListGym(ListTeam TeamA, ListTeam TeamB) {
        super(TeamA, TeamB);
    }
}