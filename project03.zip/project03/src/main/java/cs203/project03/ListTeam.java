package cs203.project03;

import java.util.*;
import cs203.battlearena.teams.Team;
import cs203.battlearena.objectmon.Objectmon;

import java.io.IOException;
/**
 * A ListTeam class
 * 
 * @author Andrew Bertella
 */
public class ListTeam<E extends Objectmon> implements Team<E>, List<E> {
    private String name;
    private int maxSize;
    private List<E> list;
    
    public ListTeam(String teamName, int maxSize) {
        this.name = teamName;
        this.maxSize = maxSize;
        this.list = new ArrayList<E>(maxSize);
    }
    public ListTeam() {
        this.name = "ListTeam";
        this.maxSize = 0;
        this.list = new ArrayList<E>(this.maxSize);
    }
    public ListTeam(String teamName) {
        this.name = teamName;
        this.maxSize = 0;
        this.list = new ArrayList<E>(this.maxSize);
    }
    public boolean add(E e) {
        if(this.list.size() < this.maxSize) {
           return this.list.add(e);
        }
    return false;
    }
    public void add(int index, E element) {
        this.list.add(index, element);
    }
    public boolean addAll(Collection<? extends E> c) {
        if(c.size()+list.size() <= this.maxSize) {
            return this.list.addAll(c);
        }
        return false;
    }
    public boolean addAll(int index, Collection<? extends E> c) {
            if(c.size()+list.size() <= this.maxSize) {
                return this.list.addAll(c);
            }
            return false;
        }
    public void clear() {
        this.list.clear();
    }
    public boolean contains(Object o) {
        return this.list.contains(o);
    }
    public boolean containsAll(Collection<?> c) {
        return list.containsAll(c);
    }
    public boolean equals(ListTeam<E> o) {
        if (this.toString().equals(o.toString()) && this.maxSize == o.getMaxSize()) {
            return true; 
        }
        return false;
    }
    public E get(int index) {
        return this.list.get(index);
    }
    public int hashCode() {
        return this.list.hashCode();
    }
    public int indexOf(Object o) {
        return this.list.indexOf(o);
    }
    public boolean isEmpty() {
        return this.list.isEmpty();
    }
    public Iterator<E> iterator() {
        return this.list.iterator();
    }
    public ListIterator<E> listIterator() {
        return this.list.listIterator();
    }
    public ListIterator<E> listIterator(int index) {
        return this.list.listIterator(index);
    }
    public E remove(int index) {
        return this.list.remove(index);
    }
    public boolean remove(Object o) {
        return this.list.remove(o);
    }
    public int lastIndexOf(Object o) {
        return this.list.lastIndexOf(o);
    }
    public boolean removeAll(Collection<?> c) {
        return this.list.removeAll(c);
    }
    public boolean retainAll(Collection<?> c) {
        return this.list.retainAll(c);
    }
    public E set(int index, E element) {
        return this.list.set(index, element);
    }
    public int size() {
        return this.list.size();
    }
    public List<E> subList(int fromIndex, int toIndex) {
        return this.list.subList(fromIndex, toIndex);
    }
    public Object[] toArray() {
        return this.list.toArray();
    }
    public <T> T[] toArray(T[] a) {
        return this.list.toArray(a);
    }
    /**
     * Helper method for testing. Sets all elements in ListTeam to e.
     * @param e
     */
    protected void setAll(E e) {
        for(int i = 0; i < this.maxSize; i++) {
            list.add(e);
        }
    }
    public boolean canFight() {
        for (E e : list) {
            if (!e.isFainted()) {
                return true;
            }
        }
    return false;
    }
    public int getMaxSize() {
        return this.maxSize;
    }
    public void setMaxSize(int n) {
        this.maxSize = n;
    }
    public String toString () {
        if (this.list.isEmpty()) {
            return String.format("%s is empty", this.name);
        }
        else {
            StringJoiner sj = new StringJoiner(", ", "[", "]");
            int num_obj = this.list.size();
            for (E e : list) {
                sj.add(e.toString());
            }
            String teamString = String.format("%s contains %s", this.name, sj.toString());
            return teamString;
        }
    }
    public E nextObjectmon() {
        for (E e : list) {
            if (!e.isFainted()) {
                return e;
            }
        }
    return null;
    }
    public String getName () {
        return this.name;
    }
    public void setName(String teamName) {
        this.name = teamName;
    } 
    public void tick() {
        for (E e : list) {
            e.tick();
        }
    }
}