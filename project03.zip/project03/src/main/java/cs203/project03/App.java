/*
 * App.java creating an instance of ListGym and calling some if its methods
 * @author Andrew Bertella
 */
package cs203.project03;

import cs203.battlearena.objectmon.Objectmon;
import java.util.*;

public class App {

    public static void main(String[] args) {
        ListGym TG = new ListGym();
        TG.createRandomTeams(10);
        System.out.println(TG.toString());
        TG.configureTeams();
        System.out.println(TG.toString());
    }
}
