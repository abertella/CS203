/**Objectdex class 
 * @author Andrew Bertella 
*/

package cs203.project06;

import java.io.*;
import java.util.NoSuchElementException;
import java.util.HashMap;
import cs203.battlearena.objectmon.*;
import com.google.gson.*;

public class JsonObjectdex extends HashMap<String, ObjectdexEntry> implements Objectdex {

    private Gson gson;

    public JsonObjectdex() {
        super();
        gson = new Gson();
    }

    public void save(String savePath) throws IOException {
        BufferedWriter out = null;
        try {
            out = new BufferedWriter(new FileWriter(savePath));
            String jsonString = gson.toJson(this.values());
            out.write(jsonString);
        } 
        catch (IOException e) {
            System.out.println("IOException:" + e.getMessage());
        }
        finally {
            if (out != null) {
                out.close();
            }
        }
    }

    public void load(String loadPath) throws IOException {
        BufferedReader in = null;
        try {
            in = new BufferedReader(new FileReader(loadPath));
            ObjectdexEntry[] values = gson.fromJson(in.readLine(), ObjectdexEntry[].class);
            for(int i=0; i < values.length; i++) {
                this.put(values[i].getName(), values[i]);
            }
        }
        catch (IOException e) {
            System.out.println("IOException:" + e.getMessage());
        }
        finally {
            if (in != null) {
                in.close();
            }
        }
    }

    public Objectmon createObjectmon(String name) throws NoSuchElementException {
        if(!this.containsKey(name)) {
            throw new NoSuchElementException("No Objectmon by that name");
        }
        ObjectdexEntry entry = this.get(name);
        String oName = entry.getName();
        int hp = entry.getHp();
        int stamina = entry.getStamina();
        int weight = entry.getWeight();
        return new Objectmon(oName, hp, stamina, weight);
    }
}