/*
 * App for the Objectdex class
 * @author Andrew Bertella
 */
package cs203.project06;

import java.io.IOException;

public class App {
    public static void main(String[] args) throws IOException {
        JsonObjectdex JsOd = new JsonObjectdex();
        JsOd.load("test.objectdex.txt");
        JsOd.save("test.objectdex2.txt");
        System.out.println(JsOd.createObjectmon("o1"));
    }
}
