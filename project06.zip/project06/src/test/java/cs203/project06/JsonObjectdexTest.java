package cs203.project06;

import org.junit.Test;
import org.junit.Before;
import cs203.project06.JsonObjectdex;
import cs203.battlearena.objectmon.*;
import java.io.IOException;
import java.util.NoSuchElementException;
import static org.junit.Assert.*;

public class JsonObjectdexTest {
    private JsonObjectdex JsOd1, JsOd2;
    private Objectmon o1, o2;

    @Before
    public void initEach() {
        JsOd1 = new JsonObjectdex();
        JsOd2 = new JsonObjectdex();
        ObjectdexEntry oE1 = new ObjectdexEntry("o1", 98, 5, 13);
        ObjectdexEntry oE2 = new ObjectdexEntry("o2", 33, 3, 5);
        JsOd1.put(oE1.getName(), oE1);
        JsOd1.put(oE2.getName(), oE2);
        o1 = new Objectmon("o1", 98, 5, 13);
        o2 = new Objectmon("o2", 33, 3, 5);

    }

    @Test
    public void testLoad() throws IOException {
        JsOd2.load("foo.txt");
        JsOd2.load("test.objectdex.txt");
        assertTrue(JsOd1.createObjectmon("o1").equals(JsOd2.createObjectmon("o1")));
        assertTrue(JsOd1.createObjectmon("o2").equals(JsOd2.createObjectmon("o2")));
    }
    @Test
    public void testSave() throws IOException {
        JsOd1.save("some~~//illegal..filename.exe");
        JsOd1.save("test.objectdex2.txt");
        JsOd2.load("test.objectdex2.txt");
        assertTrue(JsOd1.createObjectmon("o1").equals(JsOd2.createObjectmon("o1")));
        assertTrue(JsOd1.createObjectmon("o2").equals(JsOd2.createObjectmon("o2")));
    }
    @Test(expected = NoSuchElementException.class)
    public void testCreateObjectmon() {
        assertTrue(JsOd1.createObjectmon("o1").equals(o1));
        assertTrue(JsOd1.createObjectmon("o2").equals(o2));
        JsOd1.createObjectmon("o3");
    }
}