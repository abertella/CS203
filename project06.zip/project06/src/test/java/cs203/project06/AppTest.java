package cs203.project06;

import org.junit.Test;
import static org.junit.Assert.*;

public class AppTest {
}
