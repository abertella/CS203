package cs203.ec01;

import org.junit.Test;
import cs203.project04.IntegerComparator;
import cs203.ec01.BinaryTreeIterator;
import cs203.project04.BinaryTree;
import org.junit.Before;
import static org.junit.Assert.*;
import java.lang.Integer;
import java.util.Comparator;
import java.util.NoSuchElementException;

public class BinaryTreeIteratorTest {
    private BinaryTree<Integer> bTree;
    private Integer i0, i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11, i12;
    private Comparator<Integer> comp;
    private BinaryTreeIterator<Integer> iterator;

    @Before
    public void initEach() {
        i0 = 72; 
        i1 = 70; 
        i2 = 98; 
        i3 = 65; 
        i4 = 71; 
        i5 = 82;
        i6 = 101; 
        i7 = 50; 
        i8 = 68; 
        i9 = 79;
        comp = new IntegerComparator();
        bTree = new BinaryTree(comp);
        bTree.insert(i0);
        bTree.insert(i1);
        bTree.insert(i2);
        bTree.insert(i3);
        bTree.insert(i4);
        bTree.insert(i5);
        bTree.insert(i6);
        bTree.insert(i7);
        bTree.insert(i8);
        bTree.insert(i9);
        iterator = new BinaryTreeIterator<Integer>(bTree);
    }
    @Test
    public void testHasNext() {
        for(int i=0; i<9; i++) {
            assertTrue(iterator.hasNext());
            iterator.next();
        }
        assertFalse(iterator.hasNext());
    }
    @Test
    public void testNext() {
        assertTrue(iterator.next().equals(i7));
        assertTrue(iterator.next().equals(i3));
        assertTrue(iterator.next().equals(i8));
        assertTrue(iterator.next().equals(i1));
        assertTrue(iterator.next().equals(i4));
    }
}