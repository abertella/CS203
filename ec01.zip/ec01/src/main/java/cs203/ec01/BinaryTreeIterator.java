package cs203.ec01;

import cs203.project04.BinaryTree;
import java.util.Iterator;

public class BinaryTreeIterator<E> implements Iterator {
    private BinaryTree<E> iteratingFor;
    private E current;
    private E previous;

    public BinaryTreeIterator(BinaryTree<E> iteratingFor) {
        this.iteratingFor = iteratingFor;
        current = this.iteratingFor.first();
        previous = null;
    }
    public boolean hasNext() {
        if(this.iteratingFor.higher(current) != null) {
            return true;
        }
    return false;
    }
    public E next() {
        previous = current;
        current = iteratingFor.higher(previous);
        return previous;
    }
}