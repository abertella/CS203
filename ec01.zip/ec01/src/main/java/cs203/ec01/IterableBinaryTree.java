package cs203.ec01;

import cs203.ec01.BinaryTreeIterator;
import cs203.project04.BinaryTree;
import java.util.Iterator;
import java.util.Comparator;

public class IterableBinaryTree<E> extends BinaryTree<E> implements Iterable<E> {
    public IterableBinaryTree(Comparator<E> paramCompatator) {
        super(paramCompatator);
    }
    public Iterator<E> iterator() {
        return new BinaryTreeIterator(this);
    }
}