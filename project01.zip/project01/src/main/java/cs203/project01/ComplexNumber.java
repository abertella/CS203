package cs203.project01;

import java.lang.Math;
/**
 * A complex number takes the form <i>a + bi</i> where <i>a</i> is the real part and <i>bi</i> is the
 * imaginary part.
 * 
 * @author Andrew Bertella
 */
public class ComplexNumber {

	private double real;
	private double imag;

	public ComplexNumber(double real_p, double imag_p) {
		this.real = real_p;
		this.imag = imag_p;
	}
	/**
	 * Returns the real value of the complex number.
	 * @return <i>a</i> in <i>a + bi</i>
	 */
	public double getReal () {
		return this.real;
	}
	/**
	 * Returns the imaginary value of the complex number
	 * @return <i>b</i> in <i>a + bi</i>
	 */
	public double getImag () {
		return this.imag;
	}
	/**
	 * Sets the real value of the complex number.
	 * @param real_p <i>a</i> in <i>a + bi</i>
	 */
	public void setReal (double real_p) {
		this.real = real_p;
	}
	/**
	 * Sets the imaginary value of the complex number
	 * @param imag_p <i>b</i> in <i>a + bi</i>
	 */
	public void setImag (double imag_p) {
		this.imag = imag_p;
	}
	/**
	 * Adds the real and imaginary portions of two complex numbers and returns a third such that
	 * <i>(a1 + b1i) + (a2 + b2i) = (a1+a2) + (b1+b2)i</i>
	 * @param other ComplexNumber <i>a2 + b2i</i>
	 * @return  ComplexNumber <i>(a1+a2) + (b1+b2)i</i>
	 */
	public ComplexNumber add (ComplexNumber other) {
		return new ComplexNumber((this.real + other.getReal()), (this.imag + other.getImag()));
	}
	/**
	 * Subtracts the real and imaginary portions of two complex numbers and returns a third such that
	 * <i>a1 + b1i - a2 + b2i = (a1-a2) + (b1-b2)i</i>
	 * @param other ComplexNumber <i>a2 + b2i</i>
	 * @return  ComplexNumber <i>(a1-a2) + (b1-b2)i</i>
	 */
	public ComplexNumber subtract (ComplexNumber other) {
		return new ComplexNumber((this.real - other.getReal()) , (this.imag - other.getImag()));
	}
	/**
	 * Multiplies two complex numbers and returns a third. 
	 * <i>(a1+b1i)(a2+b2i) = (a1*a2-b1*b2) + (a1*b2 + a2*b1)i</i>
	 * @param other ComplexNumber <i>(a2+b2i)</i>
	 * @return ComplexNumber <i>(a1*a2-b1*b2) + (a1*b2 + a2*b1)i</i>
	 */
	public ComplexNumber multiply (ComplexNumber other) {
		double product_real = (this.real * other.getReal()) - (this.imag * other.getImag());
		double product_imag = (this.real * other.getImag()) + (this.imag * other.getReal());
		return new ComplexNumber(product_real, product_imag);
	}
	/**
	 * Divides two complex numbers by multiplying both by the conjugate of other and reducing the real and imaginary
	 * portions of the resulting complex number. (Other multiplied by its conjugate will yeild a real).
	 * Note: Other multiplied by its conjugate cannot yeild a 0 real portion. Will return NaN + NaNi.
	 * @param other ComplexNumber
	 * @return a ComplexNumber. The quotient this/other.
	 */
	public ComplexNumber divide (ComplexNumber other) {
		ComplexNumber conjugate = new ComplexNumber(other. getReal(), -(other.getImag()));
		ComplexNumber numerator = this.multiply(conjugate);
		double denominator = other.multiply(conjugate).getReal();             //Should be a + 0i - could use squaredNorm
		double quotient_real = numerator.getReal()/denominator; 
		double quotient_imag = numerator.getImag()/denominator;
		return new ComplexNumber(quotient_real, quotient_imag);
	}
	/**
	 * Returns the squared norm of a ComplexNumber by multiplying it by its conjugate. This will yeild only a real.
	 * <i>(a+bi)(a-bi) = a^2-b^2</i>
	 * @return a double. The product of a+bi and its conjugate..
	 */
	public double squaredNorm () {
		ComplexNumber conjugate = new ComplexNumber(this. getReal(), -(this.getImag()));
		return this.multiply(conjugate).getReal();
	}
	/**
	 * Returns the absolute value of the complex number. <i>abs(a + bi) = sqrt(a^2 + b^2)</i>
	 * @return A double. The absolute value of the ComplexNumber.
	 */
	public double abs () {
		return Math.sqrt((this.real * this.real) + (this.imag * this.imag));
	}
	/**
	 * Compares the real and imaginary values of two ComplexNumbers.
	 * <i>(a1+b1i) == (a2 + b2i)</i> is true only if <i>a1 == a2</i> and <i>b1 == b2</i>
	 * @param other (a2 + b2i)
	 * @return true if <i>a1 == a2</i> and <i>b1 == b2</i>, otherwise false
	 */
	public Boolean equals (ComplexNumber other) {
		return (this.real == other.getReal() && this.imag == other.getImag());
	}
	/**
	 * Generates a string representation of a ComplexNumber. I chose to format the float values to three
	 * decimal places, although formatting is arbitrary.
	 * @return A string representation of ComplexNumber A.AAA +/- B.BBBi
	 */
	public String toString() {
		if (this.imag >= 0) {
			return String.format("%.3f + %.3fi", this.real, this.imag);
		}
		else {
			return String.format("%.3f - %.3fi", this.real, -(this.imag));
		}
	}
}