/*
 * Prints the test cases for the ComplexNumber class
 * 
 * @author Andrew Bertella
 */
package cs203.project01;

public class App {
    public static void main(String[] args) {
        ComplexNumber cplx1, cplx2, cplx3, cplx4, cplx5, cplx6, cplx7, cplx8, cplx9, cplx10, cplx11, cplx12;
        cplx1 = new ComplexNumber(13.2, 3);
        cplx2 = new ComplexNumber(-11.2, 1);
        cplx3 = new ComplexNumber(5, -2);
        cplx4 = new ComplexNumber(8, 1);
        cplx5 = new ComplexNumber(18, 7);
        cplx6 = new ComplexNumber(100, -14);
        cplx7 = new ComplexNumber(43, -1);
        cplx8 = new ComplexNumber(1, 2);
        cplx9 = new ComplexNumber(115, 73);
        cplx10 = new ComplexNumber(-13, -6);
        cplx11 = new ComplexNumber(11, 3);
        cplx12 = new ComplexNumber(11, -3);
        System.out.println(cplx1.add(cplx2));
        System.out.println(cplx3.subtract(cplx4));
        System.out.println(cplx5.multiply(cplx6));
        System.out.println(cplx7.divide(cplx8));
        System.out.println(cplx9.squaredNorm());
        System.out.format("%.3f%n", cplx10.abs());  //Three places for consistancy
        System.out.println(cplx11.equals(cplx12));
    }
}
