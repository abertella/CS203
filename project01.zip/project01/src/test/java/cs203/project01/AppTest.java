/*
 * Unit tests for the ComplexNumber class.
 * 
 * @author Andrew Bertella
 */
package cs203.project01;

import org.junit.Test;
import static org.junit.Assert.*;
import java.lang.Double;

public class AppTest {
    
    double eps = 0.00001;

    @Test public void testGetReal() {
        ComplexNumber test1 = new ComplexNumber(13.2, 3);
        ComplexNumber test2 = new ComplexNumber(-45.2, 3);
        ComplexNumber test3 = new ComplexNumber(0, 15);
        assertEquals(13.2, test1.getReal(), eps);
        assertEquals(-45.2, test2.getReal(), eps);
        assertEquals(0, test3.getReal(), eps);
    }
    @Test public void testGetImag() {
        ComplexNumber test1 = new ComplexNumber(13.2, 3.1);
        ComplexNumber test2 = new ComplexNumber(-45.2, -3.32);
        ComplexNumber test3 = new ComplexNumber(12, 0);
        assertEquals(3.1, test1.getImag(), eps);
        assertEquals(-3.32, test2.getImag(), eps);
        assertEquals(0, test3.getImag(), eps);
    }
    @Test public void testSetReal() {
        ComplexNumber test = new ComplexNumber(13.2, 3);
        test.setReal(25.2);
        assertEquals(25.2, test.getReal(), eps);
        test.setReal(0);
        assertEquals(0, test.getReal(), eps);
        test.setReal(-12.3);
        assertEquals(-12.3, test.getReal(), eps);
    }
    @Test public void testSetImag() {
        ComplexNumber test = new ComplexNumber(13.2, 3);
        test.setImag(50.1);
        assertEquals(50.1, test.getImag(), eps);
        test.setImag(0);
        assertEquals(0, test.getImag(), eps);
        test.setImag(-45.3);
        assertEquals(-45.3, test.getImag(), eps);
    }
    @Test public void testAdd() {
        ComplexNumber test1 = new ComplexNumber(13.2, 3);
        ComplexNumber test2 = new ComplexNumber(-11.2, 1);
        ComplexNumber soln = new ComplexNumber(2.0, 4.0);
        assertEquals(soln.getReal(), test1.add(test2).getReal(), eps);
        assertEquals(soln.getImag(), test1.add(test2).getImag(), eps);
        assertTrue(test1.add(test2).equals(soln));          // test equals method
    }
    @Test public void testSubtract() {
        ComplexNumber test1 = new ComplexNumber(5, -2);
        ComplexNumber test2 = new ComplexNumber(8, 1);
        ComplexNumber soln = new ComplexNumber(-3.0, -3.0);
        assertEquals(soln.getReal(), test1.subtract(test2).getReal(), eps);
        assertEquals(soln.getImag(), test1.subtract(test2).getImag(), eps);
        assertTrue(test1.subtract(test2).equals(soln));     // test equals method
    }
    @Test public void testMultiply() {
        ComplexNumber test1 = new ComplexNumber(4, 5);
        ComplexNumber test2 = new ComplexNumber(9, -5);
        ComplexNumber soln = new ComplexNumber(61, 25);
        assertEquals(soln.getReal(), test1.multiply(test2).getReal(), eps);
        assertEquals(soln.getImag(), test1.multiply(test2).getImag(), eps);
        assertTrue(test1.multiply(test2).equals(soln));     // test equals method
    }
    @Test public void testDivide() {
        ComplexNumber test1 = new ComplexNumber(10, -20);
        ComplexNumber test2 = new ComplexNumber(2, 4);
        ComplexNumber test3 = new ComplexNumber(0, 0);
        ComplexNumber soln = new ComplexNumber(-3, -4);
        assertEquals(soln.getReal(), test1.divide(test2).getReal(), eps);
        assertEquals(soln.getImag(), test1.divide(test2).getImag(), eps);
        assertTrue(test1.divide(test2).equals(soln));
        assertEquals(Double.NaN, test1.divide(test3).getReal(), eps);   // divide by zero
        assertEquals(Double.NaN, test1.divide(test3).getImag(), eps);   // divide by zero
    }
    @Test public void testSquaredNorm() {
        ComplexNumber test1 = new ComplexNumber(5, 6);
        assertEquals(61, test1.squaredNorm(), eps);
    }
    @Test public void testAbs() {
        ComplexNumber test1 = new ComplexNumber(3, 4);
        ComplexNumber test2 = new ComplexNumber(115, 252);
        ComplexNumber test3 = new ComplexNumber(0, 0);
        assertEquals(5, test1.abs(), eps);
        assertEquals(277, test2.abs(), eps);
        assertEquals(0, test3.abs(), eps);
    }
    @Test public void testEquals() {
        ComplexNumber test1 = new ComplexNumber(3, 4);
        ComplexNumber test2 = new ComplexNumber(3, 4);
        ComplexNumber test3 = new ComplexNumber(-3, 4);
        ComplexNumber test4 = new ComplexNumber(3, -4);
        assertTrue(test1.equals(test1));
        assertTrue(test1.equals(test2));
        assertFalse(test3.equals(test4));
        assertTrue(new ComplexNumber(0, 0).equals(new ComplexNumber(0, 0)));
    }
    @Test public void testToString() {
        ComplexNumber test1 = new ComplexNumber(3, 4);
        ComplexNumber test2 = new ComplexNumber(-350.4, -400.2);
        assertEquals("3.000 + 4.000i", test1.toString());
        assertEquals("-350.400 - 400.200i", test2.toString());
    }
}
